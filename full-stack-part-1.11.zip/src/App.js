import React from "react";
import "./style.css";
import {useState} from 'react'

const Button = (props) => {
  const { handleClick, text } = props
  return (
      <button className='btn' onClick={handleClick}>
          {text}
      </button>
  )
}

const Statistics = (props) => {
    const{text, value, suffix} = props
  return(
      <tbody>
         <tr>
           <td><StatisticLine text={text} /></td>
           <td><StatisticLine value={value} /></td>
           <td><StatisticLine suffix={suffix} /></td>
         </tr>  
       </tbody>  
     
  )
}

const StatisticLine = (props) => {
  const {text, value, suffix} = props
  return (
    <div>
      {text} {value} {suffix}<br />
    </div>
  )
}

const App = () => {
  // save clicks of each button to its own state
  const [good, setGood] = useState(0)
  const [neutral, setNeutral] = useState(0)
  const [bad, setBad] = useState(0)
  const [all, setAll] = useState(0)
    
  const handleGoodClick = () => {
     setGood(good + 1)
     setAll(all + 1)
  }

  const handleBadClick = () => {
    setBad(bad + 1)
    setAll(all + 1)
  }

  const handleNeutralClick = () => {
    setNeutral(neutral + 1)
    setAll(all + 1)
  }

  let average = 0
  let positive = 0
  average = (good * 1) + (neutral * 0) + (bad * -1)
  average = average / all
  positive = good / all * 100
  
  if( all == 0){
    return (
      <div>
          give feedback
          <br /> <br />
          <Button handleClick={handleGoodClick} text='good' />
          <Button handleClick={handleNeutralClick} text='neutral' />
          <Button handleClick={handleBadClick} text='bad' />
          <br /> <br />
          statistics
          <br /> <br/>
          
          No feedback given      
      </div>
    )
  }else{

  return (
    <div>
        give feedback
        <br /> <br />
        <Button handleClick={handleGoodClick} text='good' />
        <Button handleClick={handleNeutralClick} text='neutral' />
        <Button handleClick={handleBadClick} text='bad' />
        <br /> <br />
        statistics
        <br /> <br/>
        
        <Statistics text='good' value={good} />
        <Statistics text='neutral' value={neutral} />
        <Statistics text='bad' value={bad} />
        <Statistics text='all' value={all} />
        <Statistics text='average' value={average} />
        <Statistics text='positive' value={positive} suffix='%' />       
    </div>
  )
  }
}

export default App