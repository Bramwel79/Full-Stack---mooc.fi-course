import React from "react";
import "./style.css";
import {useState} from 'react'

const App = () => {
  // save clicks of each button to its own state
  const [good, setGood] = useState(0)
  const [neutral, setNeutral] = useState(0)
  const [bad, setBad] = useState(0)
  const [all, setAll] = useState(0)
  let avg = 0
  let positive = 0
  
  const handleGoodClick = () => {
     setGood(good + 1)
     setAll(all + 1)
  }

  const handleBadClick = () => {
    setBad(bad + 1)
    setAll(all + 1)
  }

  const handleNeutralClick = () => {
    setNeutral(neutral + 1)
    setAll(all + 1)
  }
  
  avg = (good * 1) + (neutral * 0) + (bad * -1)
  avg = avg / all
  positive = good / all * 100
  
  return (
    <div>
        give feedback
        <br /> <br />
        <button className='btn' onClick={handleGoodClick}>good</button>
        <button className='btn' onClick={handleNeutralClick}>neutral</button>
        <button className='btn' onClick={handleBadClick}>bad</button>
        <br /> <br />
        statistics
        <br /> <br/>
        good {good} <br />
        neutral {neutral} <br />
        bad {bad} <br />
        all {all} <br />
        average {avg} <br />
        positive {positive} '%'
    </div>
  )
}

export default App