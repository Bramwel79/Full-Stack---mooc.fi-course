import React from "react";

const Header = (props) => {
  return (
    <div>
      <p>
        {props.name}
      </p>  
    </div>  
  )
}

const Content = (props) => {
  const itemlist = props.parts.map(
     item => { return <Part key={item.id} parts={item} /> }
    )
    
      return (
        <div>
          {itemlist}
        </div>
      )
}

const Part = (props) =>{
  return (
      <div>
          <p> {props.parts.name} {props.parts.exercises}</p>
      </div>
  )
}

const Total = (props) => {
  const totalsum = props.parts.reduce((sum,no) => sum + no.exercises,0)
  return (
   <div>
     <p>
       total of {totalsum} exercises
     </p>  
   </div>  
       
 )
}

const Course = (props) => {
    return(
      <div>
          <h1><Header name={props.course.name} /></h1>
          <Content parts={props.course.parts} />
          <h3><Total parts={props.course.parts} /></h3>
      </div>  
       
    )
}

export default Course