import React from "react"
import { useState, useEffect } from 'react'

import dataServices from './components/Persons'


import PersonForm from './components/PersonForm'
import Filter from './components/Filter'

import "./app.css"

const App = () => {
  const [ persons, setPersons] = useState([{ name: 'Arto Hellas', number: '040-1234567' }]) 
  const [ newName, setNewName ] = useState('')
  const [ newNumber, setNewNumber] = useState('')
  const [ filter, setFilter] = useState('')
  const [message, setMessage] = useState(["", true])

  const handleNameChange = (event) => setNewName(event.target.value)
  const handleNumberChange = (event) => setNewNumber(event.target.value)
  const handleFilterChange = (event) => setFilter(event.target.value)
  
  useEffect(() => {
    dataServices
      .extractData()
      .then(initialResult => {
        setPersons(initialResult)
      })
  }, [])

  const addPerson = (event) => {
    event.preventDefault()
    const personObject = {
      name: newName,
      number: newNumber
    }
    
    const regexp = `^${newName}$`
    const result = persons.filter(person => new RegExp(regexp, "i").test(person.name))
    if (result.length > 0) {
       window.alert(`${newName} is already added to phonebook`)
       setMessage([error.response.data.error, false])
    } else {
      dataServices.createData
      setPersons(persons.concat(personObject))
      setMessage([`Added ${personObject.name}`, true])
    }
    setNewName('')
    setNewNumber('')
  }
  
  const Persons = ({ personsToDisplay, setMessage }) => (
    <>
      {personsToDisplay.map(person => (
        <div key={person.name}>
          {person.name} {person.number}{" "}
          <DeleteButton
            id={person.id}
            name={person.name}
            setMessage={setMessage}
          />
        </div>
      ))}
    </>
  )

  const DeleteButton = ({ id, name, setMessage }) => {
    const handler = () => {
      if (window.confirm(`Delete ${name} ?`)) {
        dataServices
          .eliminate(id)
          .then(response => {
            setMessage([
              `${name} deleted successfully`,
              true,
            ])
            setTimeout(() => {
              setMessage(["", true])
            }, 3000)
          })
          .catch(response => {
            setMessage([
              `${name} has already been deleted from server`,
              false,
            ])
            setTimeout(() => {
              setMessage(["", true])
            }, 3000)
          })
      } 
    }
    return <button onClick={handler}>delete</button>
  }
  
  const Notification = ({ message }) => {
    if (message[0] === "") {
      return null
    }
    const type = message[1] ? "success" : "error"
  
    return <div className={type}>{message[0]}</div>
  }

  return (
    <div>
      <h2>Phonebook</h2>
      <Notification message={message} />
      <Filter filter={filter} onFilterChange={handleFilterChange}/>
      <h3>Add a new</h3>
      <PersonForm 
        onFormSubmit={addPerson} 
        name={newName}
        onNameChange={handleNameChange}
        number={newNumber}
        onNumberChange={handleNumberChange}
      />
      <h3>Numbers</h3>
      <Persons persons={persons} personsToDisplay={personsToDisplay} filter={filter} setMessage={setMessage}/>
    </div>
  )
}

export default App