import axios from 'axios'
const baseUrl = 'components/Persons'

const extractData = () => {
    const request = axios.get(baseUrl)
    return request.then(response => response.data)
}

const createData = newObject => {
    const request = axios.post(baseUrl, newObject)
    return request.then(response => response.data)
}

const updatePersonData = (id, newObject) => {
    const request = axios.put(`${baseUrl}/${id}`, newObject)
    return request.then(response => response.data)
  }  

const extractDeletedPersonData = id => {
    const request = axios.delete(`${baseUrl}/${id}`)
    return request.then(response => response.data)
}

const dataServices = { extractData, createData, updatePersonData, extractDeletedPersonData }

export default  dataServices 
