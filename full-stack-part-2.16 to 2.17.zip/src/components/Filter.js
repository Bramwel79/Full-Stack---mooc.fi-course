import React from 'react'

const Filter = ({ filter, onFilterChange }) => {
  return (
    <div>
      Search by person's name.Enter name:<input value={filter} onChange={onFilterChange}/>
    </div>
  )
}

export default Filter