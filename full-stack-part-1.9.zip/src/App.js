import React from "react";
import "./style.css";
import {useState} from 'react'

const Statistics = (props) => {
  const {avg,pos} = props
  return (
    <div>
      average {avg} <br />
      positive {pos} '%'
    </div>
  )
}

const App = () => {
  // save clicks of each button to its own state
  const [good, setGood] = useState(0)
  const [neutral, setNeutral] = useState(0)
  const [bad, setBad] = useState(0)
  const [all, setAll] = useState(0)
    
  const handleGoodClick = () => {
     setGood(good + 1)
     setAll(all + 1)
  }

  const handleBadClick = () => {
    setBad(bad + 1)
    setAll(all + 1)
  }

  const handleNeutralClick = () => {
    setNeutral(neutral + 1)
    setAll(all + 1)
  }

  let average = 0
  let positive = 0
  average = (good * 1) + (neutral * 0) + (bad * -1)
  average = average / all
  positive = good / all * 100
  
  if( all == 0){
    return (
      <div>
          give feedback
          <br /> <br />
          <button className='btn' onClick={handleGoodClick}>good</button>
          <button className='btn' onClick={handleNeutralClick}>neutral</button>
          <button className='btn' onClick={handleBadClick}>bad</button>
          <br /> <br />
          statistics
          <br /> <br/>
          
          No feedback given      
      </div>
    )
  }else{

  return (
    <div>
        give feedback
        <br /> <br />
        <button className='btn' onClick={handleGoodClick}>good</button>
        <button className='btn' onClick={handleNeutralClick}>neutral</button>
        <button className='btn' onClick={handleBadClick}>bad</button>
        <br /> <br />
        statistics
        <br /> <br/>
        
        good {good} <br />
        neutral {neutral} <br />
        bad {bad} <br />
        all {all} <br />
        <Statistics avg={average} pos={positive}/>         
    </div>
  )
  }
}

export default App