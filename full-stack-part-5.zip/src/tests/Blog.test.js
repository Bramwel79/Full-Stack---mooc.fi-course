import React from "react"
import "@testing-library/jest-dom/extend-expect"
import { render, screen } from "@testing-library/react"
import userEvent from "@testing-library/user-event"
import Blog from "../components/Blog"

describe("<Blog />", () => {
	const blog = {
		title: "title",
		author: "author",
		url: "http://url.com",
		likes: "10",
		user: {
			id: "1234",
		},
	}
	const user = {
		id: "1234",
	}

	let container
	let onClick = jest.fn()

	beforeEach(() => {
		container = render(
			<Blog blog={blog} updateLike={onClick} user={user} />
		).container
	})

	test("hidding a component", () => {
		const div = container.querySelector(".hidden")
		expect(div).toHaveStyle("display: none")
	})

	test("displaying a component", async () => {
		const usuario = userEvent.setup()
		const boton = screen.getByText("view")
		await usuario.click(boton)

		const div = container.querySelector(".hidden")
		expect(div).not.toHaveStyle("display: none")
	})

	test("click event handler called two times", async () => {
		const usuario = userEvent.setup()
		const botonLike = screen.getByText("like")
		await usuario.click(botonLike)
		await usuario.click(botonLike)
		expect(onClick).toHaveBeenCalledTimes(2)
	})
})