import React from "react";
import "./style.css";
import {useState} from 'react'

const App = () => {
  // save clicks of each button to its own state
  const [good, setGood] = useState(0)
  const [neutral, setNeutral] = useState(0)
  const [bad, setBad] = useState(0)
  
  const handleGoodClick = () => {
     setGood(good + 1)
  }

  const handleBadClick = () => {
    setBad(bad + 1)
  }

  const handleNeutralClick = () => {
    setNeutral(neutral + 1)
  }

  return (
    <div>
        give feedback
        <br /> <br />
        <button class='btn' onClick={handleGoodClick}>good</button>
        <button class='btn' onClick={handleNeutralClick}>neutral</button>
        <button class='btn' onClick={handleBadClick}>bad</button>
        <br /> <br />
        statistics
        <br /> <br/>
        good {good} <br />
        neutral {neutral} <br />
        bad {bad}

    </div>
  )
}

export default App