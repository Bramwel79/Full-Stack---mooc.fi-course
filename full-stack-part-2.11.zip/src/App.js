import { useState, useEffect } from "react"
import personService from "./services/persons"

const Filter = ({ newSearchName, handleSearchName }) => (
  <>
    filter shown with{" "}
    <input value={newSearchName} onChange={handleSearchName} />
  </>
)

const PersonForm = ({
  addPerson,
  newName,
  handleNameChange,
  newNumber,
  handleNumberChange,
}) => (
  <form onSubmit={addPerson}>
    <div>
      name: <input value={newName} onChange={handleNameChange} />
    </div>
    <div>
      number: <input value={newNumber} onChange={handleNumberChange} />
    </div>
    <div>
      <button type="submit">Add</button>
    </div>
  </form>
)

const Persons = ({ displayPerson, setMessage }) => (
  <>
    {displayPerson.map(person => (
      <div key={person.name}>
        {person.name} {person.number}{" "}
        <EraseButton
          id={person.id}
          name={person.name}
          setMessage={setMessage}
        />
      </div>
    ))}
  </>
)

const EraseButton = ({ id, name, setMessage }) => {
  const eraseHandler = () => {
    if (window.confirm(`Delete ${name} ?`)) {
      personService
        .erase(id)
        .then(response => {
          setMessage([
             `${name} has been deleted`,
            true,
          ])
          setTimeout(() => {
            setMessage(["", true])
          }, 3000)
        })
        .catch(response => {
          setMessage([
            `${name} has already been deleted`,
            false,
          ])
          setTimeout(() => {
            setMessage(["", true])
          }, 3000)
        })
    } 
  }
  return <button onClick={eraseHandler}>Delete</button>
}

const Notification = ({ message }) => {
  if (message[0] === "") {
    return null
  }
  const type = message[1] ? "success" : "error"

  return <div className={type}>{message[0]}</div>
}

const App = () => {
  const [persons, setPersons] = useState([])
  const [newName, setNewName] = useState("")
  const [newNumber, setNewNumber] = useState("")
  const [newSearchName, setNewSearchName] = useState("")
  const [message, setMessage] = useState(["", true])

  const fetchHook = () => {
    personService.get().then(initialPersons => {
      setPersons(initialPersons)
    })
  }

  useEffect(fetchHook, [message])

  const addPerson = event => {
    event.preventDefault()

    const personObject = {
      name: newName,
      number: newNumber,
    }

    let id = 0

    for (let i = 0; i < persons.length; i++) {
      if (persons[i].name === personObject.name) {
           id = persons[i].id
        if (window.confirm(
            `${personObject.name} is already added to phonebook, do you want to update number?`
          )
        ) {
          personService
            .put(id, personObject)
            .then(returnedPerson =>
              setPersons(
                persons.map(person =>
                  person.id !== id ? person : returnedPerson
                )
              )
            )
            .catch(error => {
              setMessage([error.response.data.error, false])
            })
        } 
        break
      }
    }

    if (id === 0) {
      personService
        .post(personObject)
        .then(returnedPerson => {
          setPersons(persons.concat(returnedPerson))
          setMessage([`Added ${returnedPerson.name} to phonebook`, true])
          setTimeout(() => {
            setMessage(["", true])
          }, 3000)
        })
        .catch(error => {
          setMessage([error.response.data.error, false])
        })
    }
    setNewName("")
    setNewNumber("")
  }

  const handleNameChange = event => {
    setNewName(event.target.value)
  }

  const handleNumberChange = event => {
    setNewNumber(event.target.value)
  }

  const handleSearchName = event => {
    setNewSearchName(event.target.value)
  }

  const personsToDisplay =
    !newSearchName || newSearchName === ""
      ? persons
      : persons.filter(person =>
          person.name.toLowerCase().includes(newSearchName.toLowerCase())
        )

  return (
    <div>
      <h1>Phonebook</h1>
      <Notification message={message} />
      <Filter
        newSearchName={newSearchName}
        handleSearchName={handleSearchName}
      />
      <h1>Add a new person</h1>
      <PersonForm
        addPerson={addPerson}
        newName={newName}
        handleNameChange={handleNameChange}
        newNumber={newNumber}
        handleNumberChange={handleNumberChange}
      />
      <h1>Numbers</h1>
      <Persons
        personsToShow={personsToDisplay}
        persons={persons}
        setPersons={setPersons}
        setMessage={setMessage}
      />
    </div>
  )
}

export default App