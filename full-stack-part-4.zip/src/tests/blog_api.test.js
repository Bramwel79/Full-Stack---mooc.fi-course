const supertest = require("supertest")
const app = require("../app")
const mongoose = require("mongoose")
const Blog = require("../models/blog")
const helper = require("./test.helper")

const api = supertest(app)

beforeAll(async () => {
	await Blog.deleteMany({})
	const blogObjects = helper.initialBlogs.map(blog => new Blog(blog))
	const blogPromises = blogObjects.map(blog => blog.save())
	await Promise.all(blogPromises)
})
describe("GET requests", () => {
	test("GET /api/blogs", async () => {
		const response = await api
			.get("/api/blogs")
			.expect(200)
			.expect("Content-Type", /application\/json/)

		expect(response.body.length).toBe(6)
	}, 100000)
})

describe("POST requests", () => {
	test("POST /api/blogs", async () => {
		const blog = {
			title: "Tesla launches cheaper Model X and Model S options with less range",
			author: "Matt Burns",
			url: "https://techcrunch.com/",
			likes: 5,
		}
		const token =
			""
		await api
			.post("/api/blogs")
			.set("Authorization", `bearer ${token}`)
			.send(blog)
			.expect(201)
			.expect("Content-Type", /application\/json/)

		const blogs = await helper.getblogsinDB()

		expect(blogs).toHaveLength(helper.initialBlogs.length + 1)
	}, 100000)

	test("POST /api/blogs", async () => {
		const blog = {
			title: "Tesla launches cheaper Model X and Model S options with less range",
			author: "Matt Burns",
			url: "https://techcrunch.com/",
			likes: 5,
		}
		const token = "BAD_TOKEN"
		await api
			.post("/api/blogs")
			.set("Authorization", `bearer ${token}`)
			.send(blog)
			.expect(401)

		const blogs = await helper.getblogsinDB()

		expect(blogs).toHaveLength(helper.initialBlogs.length)
	}, 100000)

	test("is likes property is missing", async () => {
		const blog = {
			title: "Tesla launches cheaper Model X and Model S options with less range",
			author: "Matt Burns",
			url: "https://techcrunch.com/",
      likes:5
		}

		const response = await api
			.post("/api/blogs")
			.send(blog)
			.expect(201)
			.expect("Content-Type", /application\/json/)

		expect(response.body.likes).toBeDefined()
		expect(response.body.likes).toBe(0)
	})

	test("missing title and url , backends responds with 400 Bad Request", async () => {
		const blog = {
			author: "Matt Burns",
		}

		await api.post("/api/blogs").send(blog).expect(400)
	})
})

describe("ID property is named id", () => {
	test("verify that the id property is named id", async () => {
		const response = await api
			.get("/api/blogs")
			.expect(200)
			.expect("Content-Type", /application\/json/)

		expect(response.body[0].id).toBeDefined()
		expect(response.body[0].__id).toBe(undefined)
	})
})

describe("DELETE request", () => {
	test("test deleting an existing item", async () => {
		const id = "4567"
		await api.delete(`/api/blogs/${id}`).expect(204)
	})
})

describe("PUT requests", () => {
	test("test updating an already existing blog", async () => {
		const id = "4567"
		const blog = {
			title: "Tesla launches cheaper Model X and Model S options with less range",
			author: "Matt Burns",
			url: "https://techcrunch.com/",
			likes: 5,
		}
		await api.put(`/api/blogs/${id}`).send(blog).expect(200)
	})
})

describe("POST request for creating new USERS", () => {
	test("test creating a new user with an already existing username", async () => {
		const user = {
			username: "bramwel",
			name: "bramwel nawate",
			password: "abuko123",
		}

		await api.post("/api/users").send(user).expect(400)
	})
})

afterAll(() => {
	mongoose.connection.close()
})